﻿using SemenovCursovaya.BL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SemenovCursovaya.WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    

    public partial class MainWindow : Window
    {
        string DBdatabase = "cafe_test_model";
        string DBlogin = "root";
        string DBpassword = "";
        string DBserver = "localhost";

        
        
        public MainWindow()
        {
            Application.Current.ShutdownMode = ShutdownMode.OnMainWindowClose;
            bool tryAgain()
            {
                if (MessageBox.Show("Отсутсвует подключение к бд. Попробовать снова?", "...", MessageBoxButton.YesNo) == MessageBoxResult.No)
                {
                   return false;
                    
                }
                else
                {
                    return true;
                }
            }
            InitializeComponent();
            
            DBConnection con = new DBConnection(DBdatabase, DBlogin,DBpassword, DBserver);

            MySql.Data.MySqlClient.MySqlConnection? c=null;
            c = con.Connect();
            if (c == null)
            {
                do
                {
                    if (tryAgain()==true)
                    {
                        c = con.Connect();
                    }
                    else
                    {                       
                       Close();
                       break;
                    }
                   
                       
                        

                } while (c==null);
            }
            
            
            

        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string password = textboxPassword.Password;
            string username = textboxUsername.Text;

            DBConnection con = new DBConnection(DBdatabase, DBlogin, DBpassword, DBserver);
            var c = con.Connect();
            bool islogged = loginUser(username, password, c);
            if (islogged)
            {
                MessageBox.Show("Успешный вход в приложение");
            }
            bool loginUser(string username, string password, MySql.Data.MySqlClient.MySqlConnection c)
            {
                MySql.Data.MySqlClient.MySqlCommand cmd;
                cmd = c.CreateCommand();
                cmd.CommandText = $"SELECT UserName, Password FROM `user` where UserName = '{username}';";
                var reader = cmd.ExecuteReader();
                string[] data = new string[2];
                while (reader.Read())
                {

                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        data[i] = reader.GetString(i);
                    }

                }
                if (data[0]!=null)
                {
                    if (data[1]==password)
                    {
                        return true;
                    }
                    // show info MessageBox.Show($"Login: {data[0]} Password: {data[1]}");
                }
                else
                {
                    MessageBox.Show("Invalid login or username.");
                }
                
                

                return false;
            }
        }
    }
}
