﻿using SemenovCursovaya.BL;
using SemenovCursovaya.BL.Models;


            


DBConnection con = new DBConnection("cafe_test_model", "root", "", "localhost");
var c = con.Connect();
Console.WriteLine(c.ConnectionString);

MySql.Data.MySqlClient.MySqlCommand cmd;
cmd = c.CreateCommand();
cmd.CommandText = "SELECT UserName, Password FROM `user`";
var reader = cmd.ExecuteReader();
List<string> list = new List<string>();

while (reader.Read())
{
    string myString = "";
    for (int i = 0; i < reader.FieldCount; i++)
    {
        myString += reader.GetString(i) + " | ";
    }
    //The 0 stands for "the 0'th column", so the first column of the result.
    // Do somthing with this rows string, for example to put them in to a list
    list.Add(myString);
}
foreach (var item in list)
{
    Console.WriteLine(item);
}





