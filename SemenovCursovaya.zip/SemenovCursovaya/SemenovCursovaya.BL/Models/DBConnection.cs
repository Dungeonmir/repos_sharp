﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace SemenovCursovaya.BL.Models
{
    public class DBConnection
    {
        public string Database { get; set; }
        public string User{ get; set; }
        public string Password{ get; set; }
        public string Server { get; set; }
        private MySql.Data.MySqlClient.MySqlConnection conn;
        public DBConnection(string database, string user, string password, string server)
        {
            Database = database;
            User = user;
            Password = password;
            Server = server;

        }

        public MySql.Data.MySqlClient.MySqlConnection? Connect()
        {
            try
            {
                conn = new MySql.Data.MySqlClient.MySqlConnection();
                conn.ConnectionString = $"Data Source={Server};Initial Catalog={Database};User id={User}; Password={Password};";
                try
                {
                    conn.Open();
                    Console.WriteLine("oK");
                    return conn;
                }
                catch (System.AggregateException)
                {

                    return null;
                }
                
            }
            catch (MySql.Data.MySqlClient.MySqlException ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
            
        }
    }
    
}
