﻿using Demka.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Demka.Pages
{
    /// <summary>
    /// Логика взаимодействия для ProductPage.xaml
    /// </summary>
    public partial class ProductPage : Page
    {
        List<Product> productList;
        public ProductPage()
        {
            InitializeComponent();

            productList = Entities.GetContext().Product.ToList();
            listView.ItemsSource = productList;
            comboboxSort.SelectedIndex = 0;
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            if (NavigationService.CanGoBack)
            {
                NavigationService.GoBack();
            }
            
        }

        public void UpdateData()
        {

            if (productList != null)
            {
                
                var searchText = textboxSearch.Text.ToLower();
                var result = productList.Where(product => product.ProductName.ToLower().Contains(searchText));
                if (result == null)
                {
                    result = new List<Product>();
                }
                switch (comboboxSort.SelectedIndex)
                {
                    case 0:
                        result = result.OrderBy(product => product.ProductCost);
                        break;
                    case 1:
                        result = result.OrderByDescending(product => product.ProductCost);
                        break;
                    default:
                        break;
                }

                


                listView.ItemsSource = result;

                textBoxPagination.Text = $"{result.Count()} из {productList.Count()}";
                
            }
        }

        private void textboxSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
           UpdateData();
        }

        private void comboboxSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateData();
        }

        private void listView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            NavigationService.Navigate(new EditProductPage(listView.SelectedItem as Product));
        }

        private void comboboxSortByPercent_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
