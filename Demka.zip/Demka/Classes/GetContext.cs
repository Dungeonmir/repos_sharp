﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demka.DB
{
    partial class Entities
    {
        private static Entities _instance;
        public static Entities GetContext()
        {
            if(_instance == null)
            {
                _instance = new Entities();
            }
            return _instance;
        }
    }
}
