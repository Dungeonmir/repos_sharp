﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Demka.DB
{
    public partial class Product
    {
        
        public string FullImagePath
        {
            get
            {
                if (string.IsNullOrEmpty(ProductPhoto) || string.IsNullOrWhiteSpace(ProductPhoto))
                {
                    return "../Images/picture.png";
                }
                else
                {
                    return "../Images/" + ProductPhoto;
                }
                    
            }
               
            
        }
    }
}
