﻿namespace Pract14_semenov_39_02
{
    
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxSortSpisok = new System.Windows.Forms.GroupBox();
            this.buttonSort = new System.Windows.Forms.Button();
            this.checkBoxListBox = new System.Windows.Forms.CheckBox();
            this.checkBoxComboBox = new System.Windows.Forms.CheckBox();
            this.groupBoxAddData = new System.Windows.Forms.GroupBox();
            this.btnAddData = new System.Windows.Forms.Button();
            this.radioButtonListBox = new System.Windows.Forms.RadioButton();
            this.radioButtonComboBox = new System.Windows.Forms.RadioButton();
            this.textBoxAddData = new System.Windows.Forms.TextBox();
            this.panelLeftGroup = new System.Windows.Forms.Panel();
            this.buttonColorForm = new System.Windows.Forms.Button();
            this.panelChooseData = new System.Windows.Forms.Panel();
            this.groupBoxShowData = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.listBox = new System.Windows.Forms.ListBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btnRemoveItem = new System.Windows.Forms.Button();
            this.btnRemoveItems = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnaddItem = new System.Windows.Forms.Button();
            this.btnaddItems = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.buttonShowInfoComboBox = new System.Windows.Forms.Button();
            this.groupBoxSortSpisok.SuspendLayout();
            this.groupBoxAddData.SuspendLayout();
            this.panelLeftGroup.SuspendLayout();
            this.panelChooseData.SuspendLayout();
            this.groupBoxShowData.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxSortSpisok
            // 
            this.groupBoxSortSpisok.Controls.Add(this.buttonSort);
            this.groupBoxSortSpisok.Controls.Add(this.checkBoxListBox);
            this.groupBoxSortSpisok.Controls.Add(this.checkBoxComboBox);
            this.groupBoxSortSpisok.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxSortSpisok.Location = new System.Drawing.Point(6, 130);
            this.groupBoxSortSpisok.Name = "groupBoxSortSpisok";
            this.groupBoxSortSpisok.Padding = new System.Windows.Forms.Padding(12);
            this.groupBoxSortSpisok.Size = new System.Drawing.Size(200, 101);
            this.groupBoxSortSpisok.TabIndex = 0;
            this.groupBoxSortSpisok.TabStop = false;
            this.groupBoxSortSpisok.Text = "Сортировка списков";
            this.groupBoxSortSpisok.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // buttonSort
            // 
            this.buttonSort.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonSort.Location = new System.Drawing.Point(12, 66);
            this.buttonSort.Name = "buttonSort";
            this.buttonSort.Size = new System.Drawing.Size(176, 23);
            this.buttonSort.TabIndex = 2;
            this.buttonSort.Text = "Сортировать";
            this.buttonSort.UseVisualStyleBackColor = true;
            this.buttonSort.Click += new System.EventHandler(this.buttonSort_Click);
            // 
            // checkBoxListBox
            // 
            this.checkBoxListBox.AutoSize = true;
            this.checkBoxListBox.Dock = System.Windows.Forms.DockStyle.Top;
            this.checkBoxListBox.Location = new System.Drawing.Point(12, 47);
            this.checkBoxListBox.Name = "checkBoxListBox";
            this.checkBoxListBox.Size = new System.Drawing.Size(176, 19);
            this.checkBoxListBox.TabIndex = 1;
            this.checkBoxListBox.Text = "ListBox";
            this.checkBoxListBox.UseVisualStyleBackColor = true;
            // 
            // checkBoxComboBox
            // 
            this.checkBoxComboBox.AutoSize = true;
            this.checkBoxComboBox.Dock = System.Windows.Forms.DockStyle.Top;
            this.checkBoxComboBox.Location = new System.Drawing.Point(12, 28);
            this.checkBoxComboBox.Name = "checkBoxComboBox";
            this.checkBoxComboBox.Size = new System.Drawing.Size(176, 19);
            this.checkBoxComboBox.TabIndex = 0;
            this.checkBoxComboBox.Text = "ComboBox";
            this.checkBoxComboBox.UseVisualStyleBackColor = true;
            // 
            // groupBoxAddData
            // 
            this.groupBoxAddData.Controls.Add(this.btnAddData);
            this.groupBoxAddData.Controls.Add(this.radioButtonListBox);
            this.groupBoxAddData.Controls.Add(this.radioButtonComboBox);
            this.groupBoxAddData.Controls.Add(this.textBoxAddData);
            this.groupBoxAddData.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxAddData.Location = new System.Drawing.Point(6, 6);
            this.groupBoxAddData.Name = "groupBoxAddData";
            this.groupBoxAddData.Padding = new System.Windows.Forms.Padding(12);
            this.groupBoxAddData.Size = new System.Drawing.Size(200, 124);
            this.groupBoxAddData.TabIndex = 0;
            this.groupBoxAddData.TabStop = false;
            this.groupBoxAddData.Text = "Добавление данных";
            // 
            // btnAddData
            // 
            this.btnAddData.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAddData.Location = new System.Drawing.Point(12, 89);
            this.btnAddData.Margin = new System.Windows.Forms.Padding(0);
            this.btnAddData.Name = "btnAddData";
            this.btnAddData.Size = new System.Drawing.Size(176, 23);
            this.btnAddData.TabIndex = 3;
            this.btnAddData.Text = "Добавить";
            this.btnAddData.UseVisualStyleBackColor = true;
            this.btnAddData.Click += new System.EventHandler(this.btnAddData_Click);
            // 
            // radioButtonListBox
            // 
            this.radioButtonListBox.AutoSize = true;
            this.radioButtonListBox.Dock = System.Windows.Forms.DockStyle.Top;
            this.radioButtonListBox.Location = new System.Drawing.Point(12, 70);
            this.radioButtonListBox.Name = "radioButtonListBox";
            this.radioButtonListBox.Size = new System.Drawing.Size(176, 19);
            this.radioButtonListBox.TabIndex = 2;
            this.radioButtonListBox.TabStop = true;
            this.radioButtonListBox.Text = "в ListBox";
            this.radioButtonListBox.UseVisualStyleBackColor = true;
            // 
            // radioButtonComboBox
            // 
            this.radioButtonComboBox.AutoSize = true;
            this.radioButtonComboBox.Dock = System.Windows.Forms.DockStyle.Top;
            this.radioButtonComboBox.Location = new System.Drawing.Point(12, 51);
            this.radioButtonComboBox.Name = "radioButtonComboBox";
            this.radioButtonComboBox.Size = new System.Drawing.Size(176, 19);
            this.radioButtonComboBox.TabIndex = 1;
            this.radioButtonComboBox.TabStop = true;
            this.radioButtonComboBox.Text = "В ComboBox";
            this.radioButtonComboBox.UseVisualStyleBackColor = true;
            // 
            // textBoxAddData
            // 
            this.textBoxAddData.Dock = System.Windows.Forms.DockStyle.Top;
            this.textBoxAddData.Location = new System.Drawing.Point(12, 28);
            this.textBoxAddData.Name = "textBoxAddData";
            this.textBoxAddData.Size = new System.Drawing.Size(176, 23);
            this.textBoxAddData.TabIndex = 0;
            // 
            // panelLeftGroup
            // 
            this.panelLeftGroup.Controls.Add(this.buttonColorForm);
            this.panelLeftGroup.Controls.Add(this.groupBoxSortSpisok);
            this.panelLeftGroup.Controls.Add(this.groupBoxAddData);
            this.panelLeftGroup.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelLeftGroup.Location = new System.Drawing.Point(0, 0);
            this.panelLeftGroup.Name = "panelLeftGroup";
            this.panelLeftGroup.Padding = new System.Windows.Forms.Padding(6);
            this.panelLeftGroup.Size = new System.Drawing.Size(212, 450);
            this.panelLeftGroup.TabIndex = 1;
            // 
            // buttonColorForm
            // 
            this.buttonColorForm.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonColorForm.Location = new System.Drawing.Point(6, 231);
            this.buttonColorForm.Name = "buttonColorForm";
            this.buttonColorForm.Size = new System.Drawing.Size(200, 23);
            this.buttonColorForm.TabIndex = 1;
            this.buttonColorForm.Text = "Форма с выбором цвета";
            this.buttonColorForm.UseVisualStyleBackColor = true;
            this.buttonColorForm.Click += new System.EventHandler(this.buttonColorForm_Click);
            // 
            // panelChooseData
            // 
            this.panelChooseData.Controls.Add(this.groupBoxShowData);
            this.panelChooseData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelChooseData.Location = new System.Drawing.Point(212, 0);
            this.panelChooseData.Name = "panelChooseData";
            this.panelChooseData.Padding = new System.Windows.Forms.Padding(6);
            this.panelChooseData.Size = new System.Drawing.Size(588, 450);
            this.panelChooseData.TabIndex = 2;
            // 
            // groupBoxShowData
            // 
            this.groupBoxShowData.Controls.Add(this.panel2);
            this.groupBoxShowData.Controls.Add(this.panel1);
            this.groupBoxShowData.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxShowData.Location = new System.Drawing.Point(6, 6);
            this.groupBoxShowData.Name = "groupBoxShowData";
            this.groupBoxShowData.Padding = new System.Windows.Forms.Padding(12);
            this.groupBoxShowData.Size = new System.Drawing.Size(576, 225);
            this.groupBoxShowData.TabIndex = 3;
            this.groupBoxShowData.TabStop = false;
            this.groupBoxShowData.Text = "Отоюражение и перенос данных";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(165, 28);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(259, 185);
            this.panel2.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.listBox);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(77, 0);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.panel4.Size = new System.Drawing.Size(161, 185);
            this.panel4.TabIndex = 1;
            // 
            // listBox
            // 
            this.listBox.DisplayMember = "gg";
            this.listBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox.FormattingEnabled = true;
            this.listBox.ItemHeight = 15;
            this.listBox.Location = new System.Drawing.Point(6, 0);
            this.listBox.Name = "listBox";
            this.listBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.listBox.Size = new System.Drawing.Size(149, 185);
            this.listBox.TabIndex = 0;
            this.listBox.ValueMember = "gramm";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(77, 185);
            this.panel3.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.btnRemoveItem);
            this.panel6.Controls.Add(this.btnRemoveItems);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 96);
            this.panel6.Name = "panel6";
            this.panel6.Padding = new System.Windows.Forms.Padding(12, 0, 12, 0);
            this.panel6.Size = new System.Drawing.Size(77, 89);
            this.panel6.TabIndex = 1;
            // 
            // btnRemoveItem
            // 
            this.btnRemoveItem.AutoSize = true;
            this.btnRemoveItem.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnRemoveItem.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnRemoveItem.Location = new System.Drawing.Point(12, 39);
            this.btnRemoveItem.Name = "btnRemoveItem";
            this.btnRemoveItem.Size = new System.Drawing.Size(53, 25);
            this.btnRemoveItem.TabIndex = 2;
            this.btnRemoveItem.Text = "<";
            this.btnRemoveItem.UseVisualStyleBackColor = true;
            this.btnRemoveItem.Click += new System.EventHandler(this.btnRemoveItem_Click);
            // 
            // btnRemoveItems
            // 
            this.btnRemoveItems.AutoSize = true;
            this.btnRemoveItems.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnRemoveItems.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnRemoveItems.Location = new System.Drawing.Point(12, 64);
            this.btnRemoveItems.Name = "btnRemoveItems";
            this.btnRemoveItems.Size = new System.Drawing.Size(53, 25);
            this.btnRemoveItems.TabIndex = 3;
            this.btnRemoveItems.Text = "<<";
            this.btnRemoveItems.UseVisualStyleBackColor = true;
            this.btnRemoveItems.Click += new System.EventHandler(this.btnRemoveItems_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnaddItem);
            this.panel5.Controls.Add(this.btnaddItems);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Padding = new System.Windows.Forms.Padding(12, 0, 12, 0);
            this.panel5.Size = new System.Drawing.Size(77, 96);
            this.panel5.TabIndex = 0;
            // 
            // btnaddItem
            // 
            this.btnaddItem.AutoSize = true;
            this.btnaddItem.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnaddItem.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnaddItem.Location = new System.Drawing.Point(12, 25);
            this.btnaddItem.Name = "btnaddItem";
            this.btnaddItem.Size = new System.Drawing.Size(53, 25);
            this.btnaddItem.TabIndex = 1;
            this.btnaddItem.Text = ">";
            this.btnaddItem.UseVisualStyleBackColor = true;
            this.btnaddItem.Click += new System.EventHandler(this.btnaddItem_Click);
            // 
            // btnaddItems
            // 
            this.btnaddItems.AutoSize = true;
            this.btnaddItems.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.btnaddItems.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnaddItems.Location = new System.Drawing.Point(12, 0);
            this.btnaddItems.Name = "btnaddItems";
            this.btnaddItems.Size = new System.Drawing.Size(53, 25);
            this.btnaddItems.TabIndex = 0;
            this.btnaddItems.Text = ">>";
            this.btnaddItems.UseVisualStyleBackColor = true;
            this.btnaddItems.Click += new System.EventHandler(this.btnaddItems_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.buttonShowInfoComboBox);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(12, 28);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(12, 0, 12, 0);
            this.panel1.Size = new System.Drawing.Size(153, 185);
            this.panel1.TabIndex = 1;
            // 
            // comboBox1
            // 
            this.comboBox1.DisplayMember = "Name";
            this.comboBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(12, 0);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(129, 23);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.ValueMember = "Value";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // buttonShowInfoComboBox
            // 
            this.buttonShowInfoComboBox.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttonShowInfoComboBox.Location = new System.Drawing.Point(12, 23);
            this.buttonShowInfoComboBox.Name = "buttonShowInfoComboBox";
            this.buttonShowInfoComboBox.Size = new System.Drawing.Size(129, 23);
            this.buttonShowInfoComboBox.TabIndex = 1;
            this.buttonShowInfoComboBox.Text = "Подробнее";
            this.buttonShowInfoComboBox.UseVisualStyleBackColor = true;
            this.buttonShowInfoComboBox.Click += new System.EventHandler(this.buttonShowInfoComboBox_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelChooseData);
            this.Controls.Add(this.panelLeftGroup);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBoxSortSpisok.ResumeLayout(false);
            this.groupBoxSortSpisok.PerformLayout();
            this.groupBoxAddData.ResumeLayout(false);
            this.groupBoxAddData.PerformLayout();
            this.panelLeftGroup.ResumeLayout(false);
            this.panelChooseData.ResumeLayout(false);
            this.groupBoxShowData.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
       
        private GroupBox groupBoxSortSpisok;
        private GroupBox groupBoxAddData;
        private Panel panelLeftGroup;
        private TextBox textBoxAddData;
        private RadioButton radioButtonListBox;
        private RadioButton radioButtonComboBox;
        private Button btnAddData;
        private Button buttonSort;
        private CheckBox checkBoxListBox;
        private CheckBox checkBoxComboBox;
        private Panel panelChooseData;
        private GroupBox groupBoxShowData;
        private Panel panel2;
        private Panel panel1;
        private Button btnRemoveItems;
        private Button btnRemoveItem;
        private Button btnaddItem;
        private Button btnaddItems;
        private ComboBox comboBox1;
        private Panel panel4;
        private ListBox listBox;
        private Panel panel3;
        private Panel panel6;
        private Panel panel5;
        private Button buttonColorForm;
        private Button buttonShowInfoComboBox;
    }
}